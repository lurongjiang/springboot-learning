package com.springboot.blog;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class BlogApplicationTests {

    @Test
    public void contextLoads() {
        String [] str1={"1","2","3"};
        String [] str2={"1","2","3"};
        String [] str3={"1","2","3"};
        List<String[]> list=new ArrayList<>();
        list.add(str1);list.add(str2);list.add(str3);

        String[] x = list.get(0);
        System.out.println(x.getClass());
        Object[] aa={};
        System.out.println(aa.getClass());
    }

}
