package com.springboot.blog.common;

public interface Constant {
    String CURRENT_USER = "current_user";
}
